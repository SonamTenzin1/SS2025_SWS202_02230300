package androidx.preference;

/* compiled from: PreferenceDataStore.java */
/* loaded from: classes.dex */
public abstract class e {
}
