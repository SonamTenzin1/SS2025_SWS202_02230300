package androidx.preference;

/* loaded from: classes.dex */
public final class o {
    public static final int a = 2131231194;
}
