package androidx.preference;

import cm.aptoide.pt.R;

/* loaded from: classes.dex */
public final class t {
    public static final int A0 = 9;
    public static final int B0 = 10;
    public static final int C0 = 11;
    public static final int D0 = 12;
    public static final int D1 = 0;
    public static final int E = 0;
    public static final int E0 = 13;
    public static final int E1 = 1;
    public static final int F = 1;
    public static final int F0 = 14;
    public static final int F1 = 2;
    public static final int G = 2;
    public static final int G0 = 15;
    public static final int G1 = 3;
    public static final int H = 3;
    public static final int H0 = 16;
    public static final int H1 = 4;
    public static final int I = 4;
    public static final int I0 = 17;
    public static final int I1 = 5;
    public static final int J = 5;
    public static final int J0 = 18;
    public static final int J1 = 6;
    public static final int K = 6;
    public static final int K0 = 19;
    public static final int K1 = 7;
    public static final int L = 7;
    public static final int L0 = 20;
    public static final int L1 = 8;
    public static final int M = 8;
    public static final int M0 = 21;
    public static final int M1 = 9;
    public static final int N = 9;
    public static final int N0 = 22;
    public static final int O = 10;
    public static final int O0 = 23;
    public static final int O1 = 0;
    public static final int P = 11;
    public static final int P0 = 24;
    public static final int P1 = 1;
    public static final int Q0 = 25;
    public static final int Q1 = 2;
    public static final int R0 = 26;
    public static final int R1 = 3;
    public static final int S = 0;
    public static final int S0 = 27;
    public static final int S1 = 4;
    public static final int T0 = 28;
    public static final int T1 = 5;
    public static final int U0 = 29;
    public static final int U1 = 6;
    public static final int V0 = 30;
    public static final int V1 = 7;
    public static final int W0 = 31;
    public static final int W1 = 8;
    public static final int X0 = 32;
    public static final int X1 = 9;
    public static final int Y0 = 33;
    public static final int Z0 = 34;
    public static final int a1 = 35;
    public static final int b0 = 0;
    public static final int c0 = 1;
    public static final int d0 = 2;
    public static final int d1 = 0;
    public static final int e0 = 3;
    public static final int e1 = 1;
    public static final int f0 = 4;
    public static final int f1 = 2;
    public static final int g1 = 3;
    public static final int i1 = 1;
    public static final int j1 = 2;
    public static final int k0 = 0;
    public static final int l0 = 1;
    public static final int l1 = 2;
    public static final int m0 = 2;
    public static final int m1 = 3;
    public static final int n0 = 3;
    public static final int q = 0;
    public static final int r0 = 0;
    public static final int s0 = 1;
    public static final int s1 = 1;
    public static final int t = 0;
    public static final int t0 = 2;
    public static final int t1 = 2;
    public static final int u = 1;
    public static final int u0 = 3;
    public static final int u1 = 3;
    public static final int v = 2;
    public static final int v0 = 4;
    public static final int v1 = 4;
    public static final int w = 3;
    public static final int w0 = 5;
    public static final int w1 = 5;
    public static final int x = 4;
    public static final int x0 = 6;
    public static final int x1 = 6;
    public static final int y = 5;
    public static final int y0 = 7;
    public static final int z0 = 8;
    public static final int[] a = {R.attr.background, R.attr.backgroundSplit, R.attr.backgroundStacked, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.customNavigationLayout, R.attr.displayOptions, R.attr.divider, R.attr.elevation, R.attr.height, R.attr.hideOnContentScroll, R.attr.homeAsUpIndicator, R.attr.homeLayout, R.attr.icon, R.attr.indeterminateProgressStyle, R.attr.itemPadding, R.attr.logo, R.attr.navigationMode, R.attr.popupTheme, R.attr.progressBarPadding, R.attr.progressBarStyle, R.attr.subtitle, R.attr.subtitleTextStyle, R.attr.title, R.attr.titleTextStyle};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f1886b = {android.R.attr.layout_gravity};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f1887c = {android.R.attr.minWidth};

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f1888d = new int[0];

    /* renamed from: e, reason: collision with root package name */
    public static final int[] f1889e = {R.attr.background, R.attr.backgroundSplit, R.attr.closeItemLayout, R.attr.height, R.attr.subtitleTextStyle, R.attr.titleTextStyle};

    /* renamed from: f, reason: collision with root package name */
    public static final int[] f1890f = {R.attr.expandActivityOverflowButtonDrawable, R.attr.initialActivityCount};

    /* renamed from: g, reason: collision with root package name */
    public static final int[] f1891g = {android.R.attr.layout, R.attr.buttonIconDimen, R.attr.buttonPanelSideLayout, R.attr.listItemLayout, R.attr.listLayout, R.attr.multiChoiceItemLayout, R.attr.showTitle, R.attr.singleChoiceItemLayout};

    /* renamed from: h, reason: collision with root package name */
    public static final int[] f1892h = {android.R.attr.dither, android.R.attr.visible, android.R.attr.variablePadding, android.R.attr.constantSize, android.R.attr.enterFadeDuration, android.R.attr.exitFadeDuration};

    /* renamed from: i, reason: collision with root package name */
    public static final int[] f1893i = {android.R.attr.id, android.R.attr.drawable};

    /* renamed from: j, reason: collision with root package name */
    public static final int[] f1894j = {android.R.attr.drawable, android.R.attr.toId, android.R.attr.fromId, android.R.attr.reversible};

    /* renamed from: k, reason: collision with root package name */
    public static final int[] f1895k = {android.R.attr.src, R.attr.srcCompat, R.attr.tint, R.attr.tintMode};
    public static final int[] l = {android.R.attr.thumb, R.attr.tickMark, R.attr.tickMarkTint, R.attr.tickMarkTintMode};
    public static final int[] m = {android.R.attr.textAppearance, android.R.attr.drawableTop, android.R.attr.drawableBottom, android.R.attr.drawableLeft, android.R.attr.drawableRight, android.R.attr.drawableStart, android.R.attr.drawableEnd};
    public static final int[] n = {android.R.attr.textAppearance, R.attr.autoSizeMaxTextSize, R.attr.autoSizeMinTextSize, R.attr.autoSizePresetSizes, R.attr.autoSizeStepGranularity, R.attr.autoSizeTextType, R.attr.drawableBottomCompat, R.attr.drawableEndCompat, R.attr.drawableLeftCompat, R.attr.drawableRightCompat, R.attr.drawableStartCompat, R.attr.drawableTint, R.attr.drawableTintMode, R.attr.drawableTopCompat, R.attr.firstBaselineToTopHeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.lastBaselineToBottomHeight, R.attr.lineHeight, R.attr.textAllCaps, R.attr.textLocale};
    public static final int[] o = {android.R.attr.windowIsFloating, android.R.attr.windowAnimationStyle, R.attr.actionBarDivider, R.attr.actionBarItemBackground, R.attr.actionBarPopupTheme, R.attr.actionBarSize, R.attr.actionBarSplitStyle, R.attr.actionBarStyle, R.attr.actionBarTabBarStyle, R.attr.actionBarTabStyle, R.attr.actionBarTabTextStyle, R.attr.actionBarTheme, R.attr.actionBarWidgetTheme, R.attr.actionButtonStyle, R.attr.actionDropDownStyle, R.attr.actionMenuTextAppearance, R.attr.actionMenuTextColor, R.attr.actionModeBackground, R.attr.actionModeCloseButtonStyle, R.attr.actionModeCloseDrawable, R.attr.actionModeCopyDrawable, R.attr.actionModeCutDrawable, R.attr.actionModeFindDrawable, R.attr.actionModePasteDrawable, R.attr.actionModePopupWindowStyle, R.attr.actionModeSelectAllDrawable, R.attr.actionModeShareDrawable, R.attr.actionModeSplitBackground, R.attr.actionModeStyle, R.attr.actionModeWebSearchDrawable, R.attr.actionOverflowButtonStyle, R.attr.actionOverflowMenuStyle, R.attr.activityChooserViewStyle, R.attr.alertDialogButtonGroupStyle, R.attr.alertDialogCenterButtons, R.attr.alertDialogStyle, R.attr.alertDialogTheme, R.attr.autoCompleteTextViewStyle, R.attr.borderlessButtonStyle, R.attr.buttonBarButtonStyle, R.attr.buttonBarNegativeButtonStyle, R.attr.buttonBarNeutralButtonStyle, R.attr.buttonBarPositiveButtonStyle, R.attr.buttonBarStyle, R.attr.buttonStyle, R.attr.buttonStyleSmall, R.attr.checkboxStyle, R.attr.checkedTextViewStyle, R.attr.colorAccent, R.attr.colorBackgroundFloating, R.attr.colorButtonNormal, R.attr.colorControlActivated, R.attr.colorControlHighlight, R.attr.colorControlNormal, R.attr.colorError, R.attr.colorPrimary, R.attr.colorPrimaryDark, R.attr.colorSwitchThumbNormal, R.attr.controlBackground, R.attr.dialogCornerRadius, R.attr.dialogPreferredPadding, R.attr.dialogTheme, R.attr.dividerHorizontal, R.attr.dividerVertical, R.attr.dropDownListViewStyle, R.attr.dropdownListPreferredItemHeight, R.attr.editTextBackground, R.attr.editTextColor, R.attr.editTextStyle, R.attr.homeAsUpIndicator, R.attr.imageButtonStyle, R.attr.listChoiceBackgroundIndicator, R.attr.listChoiceIndicatorMultipleAnimated, R.attr.listChoiceIndicatorSingleAnimated, R.attr.listDividerAlertDialog, R.attr.listMenuViewStyle, R.attr.listPopupWindowStyle, R.attr.listPreferredItemHeight, R.attr.listPreferredItemHeightLarge, R.attr.listPreferredItemHeightSmall, R.attr.listPreferredItemPaddingEnd, R.attr.listPreferredItemPaddingLeft, R.attr.listPreferredItemPaddingRight, R.attr.listPreferredItemPaddingStart, R.attr.panelBackground, R.attr.panelMenuListTheme, R.attr.panelMenuListWidth, R.attr.popupMenuStyle, R.attr.popupWindowStyle, R.attr.radioButtonStyle, R.attr.ratingBarStyle, R.attr.ratingBarStyleIndicator, R.attr.ratingBarStyleSmall, R.attr.searchViewStyle, R.attr.seekBarStyle, R.attr.selectableItemBackground, R.attr.selectableItemBackgroundBorderless, R.attr.spinnerDropDownItemStyle, R.attr.spinnerStyle, R.attr.switchStyle, R.attr.textAppearanceLargePopupMenu, R.attr.textAppearanceListItem, R.attr.textAppearanceListItemSecondary, R.attr.textAppearanceListItemSmall, R.attr.textAppearancePopupMenuHeader, R.attr.textAppearanceSearchResultSubtitle, R.attr.textAppearanceSearchResultTitle, R.attr.textAppearanceSmallPopupMenu, R.attr.textColorAlertDialogListItem, R.attr.textColorSearchUrl, R.attr.toolbarNavigationButtonStyle, R.attr.toolbarStyle, R.attr.tooltipForegroundColor, R.attr.tooltipFrameBackground, R.attr.viewInflaterClass, R.attr.windowActionBar, R.attr.windowActionBarOverlay, R.attr.windowActionModeOverlay, R.attr.windowFixedHeightMajor, R.attr.windowFixedHeightMinor, R.attr.windowFixedWidthMajor, R.attr.windowFixedWidthMinor, R.attr.windowMinWidthMajor, R.attr.windowMinWidthMinor, R.attr.windowNoTitle};
    public static final int[] p = {android.R.attr.selectableItemBackground, R.attr.selectableItemBackground};
    public static final int[] r = {R.attr.allowStacking};
    public static final int[] s = {android.R.attr.summaryOn, android.R.attr.summaryOff, android.R.attr.disableDependentsState, R.attr.disableDependentsState, R.attr.summaryOff, R.attr.summaryOn};
    public static final int[] z = {android.R.attr.color, android.R.attr.alpha, R.attr.alpha};
    public static final int[] A = {android.R.attr.button, R.attr.buttonCompat, R.attr.buttonTint, R.attr.buttonTintMode};
    public static final int[] B = {R.attr.keylines, R.attr.statusBarBackground};
    public static final int[] C = {android.R.attr.layout_gravity, R.attr.layout_anchor, R.attr.layout_anchorGravity, R.attr.layout_behavior, R.attr.layout_dodgeInsetEdges, R.attr.layout_insetEdge, R.attr.layout_keyline};
    public static final int[] D = {android.R.attr.dialogTitle, android.R.attr.dialogMessage, android.R.attr.dialogIcon, android.R.attr.positiveButtonText, android.R.attr.negativeButtonText, android.R.attr.dialogLayout, R.attr.dialogIcon, R.attr.dialogLayout, R.attr.dialogMessage, R.attr.dialogTitle, R.attr.negativeButtonText, R.attr.positiveButtonText};
    public static final int[] Q = {R.attr.arrowHeadLength, R.attr.arrowShaftLength, R.attr.barLength, R.attr.color, R.attr.drawableSize, R.attr.gapBetweenBars, R.attr.spinBars, R.attr.thickness};
    public static final int[] R = {R.attr.useSimpleSummaryProvider};
    public static final int[] T = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery, R.attr.fontProviderSystemFontFamily};
    public static final int[] U = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
    public static final int[] V = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
    public static final int[] W = {android.R.attr.color, android.R.attr.offset};
    public static final int[] X = {android.R.attr.gravity, android.R.attr.orientation, android.R.attr.baselineAligned, android.R.attr.baselineAlignedChildIndex, android.R.attr.weightSum, R.attr.divider, R.attr.dividerPadding, R.attr.measureWithLargestChild, R.attr.showDividers};
    public static final int[] Y = {android.R.attr.layout_gravity, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_weight};
    public static final int[] Z = {android.R.attr.dropDownHorizontalOffset, android.R.attr.dropDownVerticalOffset};
    public static final int[] a0 = {android.R.attr.entries, android.R.attr.entryValues, R.attr.entries, R.attr.entryValues, R.attr.useSimpleSummaryProvider};
    public static final int[] g0 = {android.R.attr.enabled, android.R.attr.id, android.R.attr.visible, android.R.attr.menuCategory, android.R.attr.orderInCategory, android.R.attr.checkableBehavior};
    public static final int[] h0 = {android.R.attr.icon, android.R.attr.enabled, android.R.attr.id, android.R.attr.checked, android.R.attr.visible, android.R.attr.menuCategory, android.R.attr.orderInCategory, android.R.attr.title, android.R.attr.titleCondensed, android.R.attr.alphabeticShortcut, android.R.attr.numericShortcut, android.R.attr.checkable, android.R.attr.onClick, R.attr.actionLayout, R.attr.actionProviderClass, R.attr.actionViewClass, R.attr.alphabeticModifiers, R.attr.contentDescription, R.attr.iconTint, R.attr.iconTintMode, R.attr.numericModifiers, R.attr.showAsAction, R.attr.tooltipText};
    public static final int[] i0 = {android.R.attr.windowAnimationStyle, android.R.attr.itemTextAppearance, android.R.attr.horizontalDivider, android.R.attr.verticalDivider, android.R.attr.headerBackground, android.R.attr.itemBackground, android.R.attr.itemIconDisabledAlpha, R.attr.preserveIconSpacing, R.attr.subMenuArrow};
    public static final int[] j0 = {android.R.attr.entries, android.R.attr.entryValues, R.attr.entries, R.attr.entryValues};
    public static final int[] o0 = {android.R.attr.popupBackground, android.R.attr.popupAnimationStyle, R.attr.overlapAnchor};
    public static final int[] p0 = {R.attr.state_above_anchor};
    public static final int[] q0 = {android.R.attr.icon, android.R.attr.persistent, android.R.attr.enabled, android.R.attr.layout, android.R.attr.title, android.R.attr.selectable, android.R.attr.key, android.R.attr.summary, android.R.attr.order, android.R.attr.widgetLayout, android.R.attr.dependency, android.R.attr.defaultValue, android.R.attr.shouldDisableView, android.R.attr.fragment, android.R.attr.singleLineTitle, android.R.attr.iconSpaceReserved, R.attr.allowDividerAbove, R.attr.allowDividerBelow, R.attr.defaultValue, R.attr.dependency, R.attr.enableCopying, R.attr.enabled, R.attr.fragment, R.attr.icon, R.attr.iconSpaceReserved, R.attr.isPreferenceVisible, R.attr.key, R.attr.layout, R.attr.order, R.attr.persistent, R.attr.selectable, R.attr.shouldDisableView, R.attr.singleLineTitle, R.attr.summary, R.attr.title, R.attr.widgetLayout};
    public static final int[] b1 = {android.R.attr.layout, android.R.attr.divider, android.R.attr.dividerHeight, R.attr.allowDividerAfterLastItem};
    public static final int[] c1 = {android.R.attr.layout, android.R.attr.divider, android.R.attr.dividerHeight, R.attr.allowDividerAfterLastItem};
    public static final int[] h1 = {android.R.attr.orderingFromXml, R.attr.initialExpandedChildrenCount, R.attr.orderingFromXml};
    public static final int[] k1 = {android.R.attr.maxWidth, android.R.attr.maxHeight, R.attr.maxHeight, R.attr.maxWidth};
    public static final int[] n1 = {R.attr.checkBoxPreferenceStyle, R.attr.dialogPreferenceStyle, R.attr.dropdownPreferenceStyle, R.attr.editTextPreferenceStyle, R.attr.preferenceCategoryStyle, R.attr.preferenceCategoryTitleTextAppearance, R.attr.preferenceFragmentCompatStyle, R.attr.preferenceFragmentListStyle, R.attr.preferenceFragmentStyle, R.attr.preferenceInformationStyle, R.attr.preferenceScreenStyle, R.attr.preferenceStyle, R.attr.preferenceTheme, R.attr.seekBarPreferenceStyle, R.attr.switchPreferenceCompatStyle, R.attr.switchPreferenceStyle};
    public static final int[] o1 = {R.attr.paddingBottomNoButtons, R.attr.paddingTopNoTitle};
    public static final int[] p1 = {android.R.attr.orientation, android.R.attr.clipToPadding, android.R.attr.descendantFocusability, R.attr.fastScrollEnabled, R.attr.fastScrollHorizontalThumbDrawable, R.attr.fastScrollHorizontalTrackDrawable, R.attr.fastScrollVerticalThumbDrawable, R.attr.fastScrollVerticalTrackDrawable, R.attr.layoutManager, R.attr.reverseLayout, R.attr.spanCount, R.attr.stackFromEnd};
    public static final int[] q1 = {android.R.attr.focusable, android.R.attr.maxWidth, android.R.attr.inputType, android.R.attr.imeOptions, R.attr.closeIcon, R.attr.commitIcon, R.attr.defaultQueryHint, R.attr.goIcon, R.attr.iconifiedByDefault, R.attr.layout, R.attr.queryBackground, R.attr.queryHint, R.attr.searchHintIcon, R.attr.searchIcon, R.attr.submitBackground, R.attr.suggestionRowLayout, R.attr.voiceIcon};
    public static final int[] r1 = {android.R.attr.layout, android.R.attr.max, R.attr.adjustable, R.attr.min, R.attr.seekBarIncrement, R.attr.showSeekBarValue, R.attr.updatesContinuously};
    public static final int[] y1 = {android.R.attr.entries, android.R.attr.popupBackground, android.R.attr.prompt, android.R.attr.dropDownWidth, R.attr.popupTheme};
    public static final int[] z1 = {android.R.attr.dither, android.R.attr.visible, android.R.attr.variablePadding, android.R.attr.constantSize, android.R.attr.enterFadeDuration, android.R.attr.exitFadeDuration};
    public static final int[] A1 = {android.R.attr.drawable};
    public static final int[] B1 = {android.R.attr.textOn, android.R.attr.textOff, android.R.attr.thumb, R.attr.showText, R.attr.splitTrack, R.attr.switchMinWidth, R.attr.switchPadding, R.attr.switchTextAppearance, R.attr.thumbTextPadding, R.attr.thumbTint, R.attr.thumbTintMode, R.attr.track, R.attr.trackTint, R.attr.trackTintMode};
    public static final int[] C1 = {android.R.attr.summaryOn, android.R.attr.summaryOff, android.R.attr.disableDependentsState, android.R.attr.switchTextOn, android.R.attr.switchTextOff, R.attr.disableDependentsState, R.attr.summaryOff, R.attr.summaryOn, R.attr.switchTextOff, R.attr.switchTextOn};
    public static final int[] N1 = {android.R.attr.summaryOn, android.R.attr.summaryOff, android.R.attr.disableDependentsState, android.R.attr.switchTextOn, android.R.attr.switchTextOff, R.attr.disableDependentsState, R.attr.summaryOff, R.attr.summaryOn, R.attr.switchTextOff, R.attr.switchTextOn};
    public static final int[] Y1 = {android.R.attr.textSize, android.R.attr.typeface, android.R.attr.textStyle, android.R.attr.textColor, android.R.attr.textColorHint, android.R.attr.textColorLink, android.R.attr.shadowColor, android.R.attr.shadowDx, android.R.attr.shadowDy, android.R.attr.shadowRadius, android.R.attr.fontFamily, android.R.attr.textFontWeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.textAllCaps, R.attr.textLocale};
    public static final int[] Z1 = {android.R.attr.gravity, android.R.attr.minHeight, R.attr.buttonGravity, R.attr.collapseContentDescription, R.attr.collapseIcon, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.logo, R.attr.logoDescription, R.attr.maxButtonHeight, R.attr.menu, R.attr.navigationContentDescription, R.attr.navigationIcon, R.attr.popupTheme, R.attr.subtitle, R.attr.subtitleTextAppearance, R.attr.subtitleTextColor, R.attr.title, R.attr.titleMargin, R.attr.titleMarginBottom, R.attr.titleMarginEnd, R.attr.titleMarginStart, R.attr.titleMarginTop, R.attr.titleMargins, R.attr.titleTextAppearance, R.attr.titleTextColor};
    public static final int[] a2 = {android.R.attr.theme, android.R.attr.focusable, R.attr.paddingEnd, R.attr.paddingStart, R.attr.theme};
    public static final int[] b2 = {android.R.attr.background, R.attr.backgroundTint, R.attr.backgroundTintMode};
    public static final int[] c2 = {android.R.attr.id, android.R.attr.layout, android.R.attr.inflatedId};
}
