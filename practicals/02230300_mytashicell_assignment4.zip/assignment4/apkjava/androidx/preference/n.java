package androidx.preference;

/* loaded from: classes.dex */
public final class n {
    public static final int a = 2131099983;
}
