package androidx.preference;

/* loaded from: classes.dex */
public final class p {
    public static final int a = 2131296840;

    /* renamed from: b, reason: collision with root package name */
    public static final int f1874b = 2131297128;

    /* renamed from: c, reason: collision with root package name */
    public static final int f1875c = 2131297189;

    /* renamed from: d, reason: collision with root package name */
    public static final int f1876d = 2131297190;

    /* renamed from: e, reason: collision with root package name */
    public static final int f1877e = 2131297234;

    /* renamed from: f, reason: collision with root package name */
    public static final int f1878f = 2131297270;
}
