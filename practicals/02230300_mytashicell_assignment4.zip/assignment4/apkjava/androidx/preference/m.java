package androidx.preference;

/* loaded from: classes.dex */
public final class m {
    public static final int a = 2130968744;

    /* renamed from: b, reason: collision with root package name */
    public static final int f1864b = 2130968791;

    /* renamed from: c, reason: collision with root package name */
    public static final int f1865c = 2130968907;

    /* renamed from: d, reason: collision with root package name */
    public static final int f1866d = 2130968938;

    /* renamed from: e, reason: collision with root package name */
    public static final int f1867e = 2130968944;

    /* renamed from: f, reason: collision with root package name */
    public static final int f1868f = 2130969371;

    /* renamed from: g, reason: collision with root package name */
    public static final int f1869g = 2130969373;

    /* renamed from: h, reason: collision with root package name */
    public static final int f1870h = 2130969377;

    /* renamed from: i, reason: collision with root package name */
    public static final int f1871i = 2130969378;

    /* renamed from: j, reason: collision with root package name */
    public static final int f1872j = 2130969381;

    /* renamed from: k, reason: collision with root package name */
    public static final int f1873k = 2130969471;
    public static final int l = 2130969557;
    public static final int m = 2130969558;
}
