package androidx.preference;

/* loaded from: classes.dex */
public final class r {
    public static final int a = 2131820885;

    /* renamed from: b, reason: collision with root package name */
    public static final int f1882b = 2131820986;

    /* renamed from: c, reason: collision with root package name */
    public static final int f1883c = 2131821257;

    /* renamed from: d, reason: collision with root package name */
    public static final int f1884d = 2131821310;

    /* renamed from: e, reason: collision with root package name */
    public static final int f1885e = 2131821545;
}
