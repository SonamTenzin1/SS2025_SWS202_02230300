package androidx.preference;

/* loaded from: classes.dex */
public final class s {
    public static final int a = 2131886590;
}
