package androidx.preference;

/* loaded from: classes.dex */
public final class q {
    public static final int a = 2131493012;

    /* renamed from: b, reason: collision with root package name */
    public static final int f1879b = 2131493125;

    /* renamed from: c, reason: collision with root package name */
    public static final int f1880c = 2131493133;

    /* renamed from: d, reason: collision with root package name */
    public static final int f1881d = 2131493135;
}
