package androidx.datastore.core;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: SingleProcessDataStore.kt */
/* loaded from: classes.dex */
public abstract class m<T> {
    private m() {
    }

    public /* synthetic */ m(kotlin.jvm.internal.g gVar) {
        this();
    }
}
