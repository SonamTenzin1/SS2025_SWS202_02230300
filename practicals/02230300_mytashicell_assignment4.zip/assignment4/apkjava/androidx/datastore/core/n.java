package androidx.datastore.core;

/* compiled from: SingleProcessDataStore.kt */
/* loaded from: classes.dex */
final class n extends m<Object> {
    public static final n a = new n();

    private n() {
        super(null);
    }
}
