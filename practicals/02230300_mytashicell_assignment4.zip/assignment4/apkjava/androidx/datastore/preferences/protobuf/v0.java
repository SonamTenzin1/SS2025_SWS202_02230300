package androidx.datastore.preferences.protobuf;

/* compiled from: NewInstanceSchema.java */
/* loaded from: classes.dex */
interface v0 {
    Object a(Object obj);
}
