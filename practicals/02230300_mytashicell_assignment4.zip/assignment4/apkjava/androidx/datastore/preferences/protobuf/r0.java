package androidx.datastore.preferences.protobuf;

/* compiled from: MessageLiteOrBuilder.java */
/* loaded from: classes.dex */
public interface r0 {
    q0 b();

    boolean isInitialized();
}
