package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public /* synthetic */ class i {
    public static /* synthetic */ int a(int i2, int i3) {
        if (i2 == i3) {
            return 0;
        }
        return i2 < i3 ? -1 : 1;
    }
}
