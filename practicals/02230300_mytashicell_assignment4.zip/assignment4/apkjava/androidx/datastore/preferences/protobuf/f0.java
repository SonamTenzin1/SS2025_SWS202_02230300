package androidx.datastore.preferences.protobuf;

import java.util.List;

/* compiled from: LazyStringList.java */
/* loaded from: classes.dex */
public interface f0 extends List {
    void a0(h hVar);

    Object c1(int i2);

    List<?> j();

    f0 k();
}
