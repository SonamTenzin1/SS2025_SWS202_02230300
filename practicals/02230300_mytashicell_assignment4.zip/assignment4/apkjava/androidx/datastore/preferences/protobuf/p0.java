package androidx.datastore.preferences.protobuf;

/* compiled from: MessageInfoFactory.java */
/* loaded from: classes.dex */
interface p0 {
    o0 a(Class<?> cls);

    boolean b(Class<?> cls);
}
