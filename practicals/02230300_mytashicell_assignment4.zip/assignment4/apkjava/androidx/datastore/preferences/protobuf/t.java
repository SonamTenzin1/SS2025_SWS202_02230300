package androidx.datastore.preferences.protobuf;

/* compiled from: FieldInfo.java */
/* loaded from: classes.dex */
final class t implements Comparable<t> {
}
