package androidx.datastore.preferences.protobuf;

/* compiled from: SchemaFactory.java */
/* loaded from: classes.dex */
interface g1 {
    <T> f1<T> a(Class<T> cls);
}
