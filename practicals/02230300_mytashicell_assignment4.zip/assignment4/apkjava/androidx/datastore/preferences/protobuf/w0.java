package androidx.datastore.preferences.protobuf;

import androidx.datastore.preferences.protobuf.y;

/* compiled from: NewInstanceSchemaLite.java */
/* loaded from: classes.dex */
final class w0 implements v0 {
    @Override // androidx.datastore.preferences.protobuf.v0
    public Object a(Object obj) {
        return ((y) obj).s(y.f.NEW_MUTABLE_INSTANCE);
    }
}
