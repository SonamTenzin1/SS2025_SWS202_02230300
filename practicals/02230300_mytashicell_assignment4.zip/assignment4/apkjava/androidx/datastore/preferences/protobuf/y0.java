package androidx.datastore.preferences.protobuf;

/* compiled from: Parser.java */
/* loaded from: classes.dex */
public interface y0<MessageType> {
    MessageType a(h hVar, p pVar) throws InvalidProtocolBufferException;

    MessageType b(j jVar, p pVar) throws InvalidProtocolBufferException;
}
