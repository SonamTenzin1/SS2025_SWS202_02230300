package androidx.datastore.preferences.protobuf;

/* compiled from: PrimitiveNonBoxingCollection.java */
/* loaded from: classes.dex */
interface z0 {
}
