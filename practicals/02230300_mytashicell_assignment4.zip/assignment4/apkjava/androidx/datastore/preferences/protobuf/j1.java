package androidx.datastore.preferences.protobuf;

/* compiled from: StructuralMessageInfo.java */
/* loaded from: classes.dex */
final class j1 implements o0 {
    private final a1 a;

    /* renamed from: b, reason: collision with root package name */
    private final boolean f1355b;

    /* renamed from: c, reason: collision with root package name */
    private final int[] f1356c;

    /* renamed from: d, reason: collision with root package name */
    private final t[] f1357d;

    /* renamed from: e, reason: collision with root package name */
    private final q0 f1358e;

    @Override // androidx.datastore.preferences.protobuf.o0
    public boolean a() {
        return this.f1355b;
    }

    @Override // androidx.datastore.preferences.protobuf.o0
    public q0 b() {
        return this.f1358e;
    }

    @Override // androidx.datastore.preferences.protobuf.o0
    public a1 c() {
        return this.a;
    }

    public int[] d() {
        return this.f1356c;
    }

    public t[] e() {
        return this.f1357d;
    }
}
