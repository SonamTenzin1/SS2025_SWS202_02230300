package androidx.datastore.preferences.protobuf;

/* compiled from: MessageInfo.java */
/* loaded from: classes.dex */
interface o0 {
    boolean a();

    q0 b();

    a1 c();
}
