package androidx.datastore.preferences.protobuf;

/* compiled from: ProtoSyntax.java */
/* loaded from: classes.dex */
public enum a1 {
    PROTO2,
    PROTO3
}
