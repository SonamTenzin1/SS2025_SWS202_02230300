package androidx.datastore.preferences.protobuf;

import java.io.IOException;

/* compiled from: ByteOutput.java */
/* loaded from: classes.dex */
public abstract class g {
    public abstract void a(byte[] bArr, int i2, int i3) throws IOException;
}
