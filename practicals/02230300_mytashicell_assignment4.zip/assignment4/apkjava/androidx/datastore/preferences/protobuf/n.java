package androidx.datastore.preferences.protobuf;

import androidx.datastore.preferences.protobuf.q0;

/* compiled from: ExtensionLite.java */
/* loaded from: classes.dex */
public abstract class n<ContainingType extends q0, Type> {
}
