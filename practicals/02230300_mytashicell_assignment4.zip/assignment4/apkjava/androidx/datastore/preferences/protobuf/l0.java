package androidx.datastore.preferences.protobuf;

import androidx.datastore.preferences.protobuf.j0;
import java.util.Map;

/* compiled from: MapFieldSchema.java */
/* loaded from: classes.dex */
interface l0 {
    Object a(Object obj, Object obj2);

    Object b(Object obj);

    j0.a<?, ?> c(Object obj);

    Map<?, ?> d(Object obj);

    Object e(Object obj);

    int f(int i2, Object obj, Object obj2);

    boolean g(Object obj);

    Map<?, ?> h(Object obj);
}
