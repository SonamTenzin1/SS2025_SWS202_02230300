package androidx.datastore.preferences.protobuf;

import java.io.IOException;

/* compiled from: Schema.java */
/* loaded from: classes.dex */
interface f1<T> {
    void a(T t, T t2);

    boolean b(T t, T t2);

    T c();

    int d(T t);

    void e(T t, e1 e1Var, p pVar) throws IOException;

    void f(T t);

    boolean g(T t);

    void h(T t, s1 s1Var) throws IOException;

    int i(T t);
}
