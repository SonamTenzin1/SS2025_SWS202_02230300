package androidx.core.view;

/* compiled from: OnReceiveContentViewBehavior.java */
/* loaded from: classes.dex */
public interface q {
}
