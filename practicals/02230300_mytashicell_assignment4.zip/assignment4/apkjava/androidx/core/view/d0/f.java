package androidx.core.view.d0;

import android.os.Bundle;
import android.view.View;

/* compiled from: AccessibilityViewCommand.java */
/* loaded from: classes.dex */
public interface f {

    /* compiled from: AccessibilityViewCommand.java */
    /* loaded from: classes.dex */
    public static abstract class a {
        Bundle a;

        public void a(Bundle bundle) {
            this.a = bundle;
        }
    }

    /* compiled from: AccessibilityViewCommand.java */
    /* loaded from: classes.dex */
    public static final class b extends a {
    }

    /* compiled from: AccessibilityViewCommand.java */
    /* loaded from: classes.dex */
    public static final class c extends a {
    }

    /* compiled from: AccessibilityViewCommand.java */
    /* loaded from: classes.dex */
    public static final class d extends a {
    }

    /* compiled from: AccessibilityViewCommand.java */
    /* loaded from: classes.dex */
    public static final class e extends a {
    }

    /* compiled from: AccessibilityViewCommand.java */
    /* renamed from: androidx.core.view.d0.f$f, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static final class C0026f extends a {
    }

    /* compiled from: AccessibilityViewCommand.java */
    /* loaded from: classes.dex */
    public static final class g extends a {
    }

    /* compiled from: AccessibilityViewCommand.java */
    /* loaded from: classes.dex */
    public static final class h extends a {
    }

    boolean a(View view, a aVar);
}
