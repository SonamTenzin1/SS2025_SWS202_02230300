package androidx.core.view;

import android.view.View;

/* compiled from: NestedScrollingParent3.java */
/* loaded from: classes.dex */
public interface m extends l {
    void j(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr);
}
