package androidx.core.view;

import android.view.View;

/* compiled from: ViewPropertyAnimatorUpdateListener.java */
/* loaded from: classes.dex */
public interface b0 {
    void a(View view);
}
