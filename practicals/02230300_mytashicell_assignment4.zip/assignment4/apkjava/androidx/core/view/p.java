package androidx.core.view;

import android.view.View;

/* compiled from: OnApplyWindowInsetsListener.java */
/* loaded from: classes.dex */
public interface p {
    c0 a(View view, c0 c0Var);
}
