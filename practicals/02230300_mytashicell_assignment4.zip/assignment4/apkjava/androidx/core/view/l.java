package androidx.core.view;

import android.view.View;

/* compiled from: NestedScrollingParent2.java */
/* loaded from: classes.dex */
public interface l extends n {
    void k(View view, int i2, int i3, int i4, int i5, int i6);

    boolean l(View view, View view2, int i2, int i3);

    void m(View view, View view2, int i2, int i3);

    void n(View view, int i2);

    void o(View view, int i2, int i3, int[] iArr, int i4);
}
