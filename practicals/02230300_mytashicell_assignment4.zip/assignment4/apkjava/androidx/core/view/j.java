package androidx.core.view;

/* compiled from: NestedScrollingChild.java */
/* loaded from: classes.dex */
public interface j {
    boolean isNestedScrollingEnabled();

    void stopNestedScroll();
}
