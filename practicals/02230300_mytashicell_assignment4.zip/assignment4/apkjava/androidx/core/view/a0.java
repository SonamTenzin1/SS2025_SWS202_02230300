package androidx.core.view;

import android.view.View;

/* compiled from: ViewPropertyAnimatorListenerAdapter.java */
/* loaded from: classes.dex */
public class a0 implements z {
    @Override // androidx.core.view.z
    public void onAnimationCancel(View view) {
    }

    @Override // androidx.core.view.z
    public void onAnimationEnd(View view) {
        throw null;
    }

    @Override // androidx.core.view.z
    public void onAnimationStart(View view) {
    }
}
