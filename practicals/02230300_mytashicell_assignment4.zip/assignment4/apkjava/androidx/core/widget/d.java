package androidx.core.widget;

import android.os.Build;

/* compiled from: AutoSizeableTextView.java */
/* loaded from: classes.dex */
public interface d {
    public static final boolean a;

    static {
        a = Build.VERSION.SDK_INT >= 27;
    }
}
