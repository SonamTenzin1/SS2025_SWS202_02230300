package androidx.core.app;

/* compiled from: SharedElementCallback.java */
/* loaded from: classes.dex */
public abstract class o {
}
