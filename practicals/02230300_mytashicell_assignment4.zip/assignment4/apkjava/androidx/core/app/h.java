package androidx.core.app;

import android.app.Notification;

/* compiled from: NotificationBuilderWithBuilderAccessor.java */
/* loaded from: classes.dex */
public interface h {
    Notification.Builder a();
}
