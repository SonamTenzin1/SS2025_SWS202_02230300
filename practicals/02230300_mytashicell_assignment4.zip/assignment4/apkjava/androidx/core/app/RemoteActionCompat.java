package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements androidx.versionedparcelable.b {
    public IconCompat a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f840b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f841c;

    /* renamed from: d, reason: collision with root package name */
    public PendingIntent f842d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f843e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f844f;
}
