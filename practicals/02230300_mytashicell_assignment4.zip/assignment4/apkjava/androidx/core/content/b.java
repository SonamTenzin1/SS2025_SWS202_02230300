package androidx.core.content;

/* compiled from: LocusIdCompat.java */
/* loaded from: classes.dex */
public final class b {
}
