package androidx.core.graphics.drawable;

import android.graphics.drawable.Drawable;

/* compiled from: WrappedDrawable.java */
/* loaded from: classes.dex */
public interface c {
    void a(Drawable drawable);

    Drawable b();
}
