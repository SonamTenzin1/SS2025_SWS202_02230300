package androidx.appcompat.app;

import c.a.o.b;

/* compiled from: AppCompatCallback.java */
/* loaded from: classes.dex */
public interface e {
    void onSupportActionModeFinished(c.a.o.b bVar);

    void onSupportActionModeStarted(c.a.o.b bVar);

    c.a.o.b onWindowStartingSupportActionMode(b.a aVar);
}
