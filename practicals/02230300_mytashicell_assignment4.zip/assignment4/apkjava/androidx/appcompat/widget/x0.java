package androidx.appcompat.widget;

/* compiled from: WithHint.java */
/* loaded from: classes.dex */
public interface x0 {
    CharSequence a();
}
