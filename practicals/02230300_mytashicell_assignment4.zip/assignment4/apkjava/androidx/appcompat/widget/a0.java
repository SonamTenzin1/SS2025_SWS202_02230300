package androidx.appcompat.widget;

import android.graphics.Rect;

/* compiled from: FitWindowsViewGroup.java */
/* loaded from: classes.dex */
public interface a0 {

    /* compiled from: FitWindowsViewGroup.java */
    /* loaded from: classes.dex */
    public interface a {
        void a(Rect rect);
    }

    void setOnFitSystemWindowsListener(a aVar);
}
