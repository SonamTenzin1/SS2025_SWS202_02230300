package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.view.menu.m;

/* compiled from: DecorContentParent.java */
/* loaded from: classes.dex */
public interface w {
    void a(Menu menu, m.a aVar);

    boolean b();

    void c();

    boolean d();

    boolean e();

    boolean f();

    boolean g();

    void h(int i2);

    void i();

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
