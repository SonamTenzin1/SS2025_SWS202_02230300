package androidx.appcompat.widget;

import android.view.MenuItem;

/* compiled from: MenuItemHoverListener.java */
/* loaded from: classes.dex */
public interface e0 {
    void d(androidx.appcompat.view.menu.g gVar, MenuItem menuItem);

    void g(androidx.appcompat.view.menu.g gVar, MenuItem menuItem);
}
