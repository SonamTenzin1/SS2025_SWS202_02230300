package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* compiled from: TintInfo.java */
/* loaded from: classes.dex */
public class o0 {
    public ColorStateList a;

    /* renamed from: b, reason: collision with root package name */
    public PorterDuff.Mode f594b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f595c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f596d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a() {
        this.a = null;
        this.f596d = false;
        this.f594b = null;
        this.f595c = false;
    }
}
