package androidx.appcompat.view.menu;

/* compiled from: MenuView.java */
/* loaded from: classes.dex */
public interface n {

    /* compiled from: MenuView.java */
    /* loaded from: classes.dex */
    public interface a {
        boolean d();

        void e(i iVar, int i2);

        i getItemData();
    }

    void b(g gVar);
}
