package androidx.appcompat.view.menu;

import android.widget.ListView;

/* compiled from: ShowableListMenu.java */
/* loaded from: classes.dex */
public interface p {
    boolean a();

    void dismiss();

    ListView j();

    void show();
}
