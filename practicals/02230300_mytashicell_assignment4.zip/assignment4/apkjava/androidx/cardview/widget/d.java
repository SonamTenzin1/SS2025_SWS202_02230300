package androidx.cardview.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

/* compiled from: CardViewDelegate.java */
/* loaded from: classes.dex */
interface d {
    void a(int i2, int i3, int i4, int i5);

    void b(int i2, int i3);

    void c(Drawable drawable);

    boolean d();

    boolean e();

    Drawable f();

    View g();
}
