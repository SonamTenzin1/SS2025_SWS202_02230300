package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;

/* compiled from: CardViewImpl.java */
/* loaded from: classes.dex */
interface e {
    void a(d dVar, Context context, ColorStateList colorStateList, float f2, float f3, float f4);

    void b(d dVar, float f2);

    float c(d dVar);

    float d(d dVar);

    void e(d dVar);

    void f(d dVar, float f2);

    float g(d dVar);

    ColorStateList h(d dVar);

    void i(d dVar);

    void j();

    float k(d dVar);

    float l(d dVar);

    void m(d dVar);

    void n(d dVar, ColorStateList colorStateList);

    void o(d dVar, float f2);
}
