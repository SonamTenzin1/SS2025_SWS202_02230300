package androidx.lifecycle;

import android.view.View;

/* compiled from: ViewTreeViewModelStoreOwner.java */
/* loaded from: classes.dex */
public class c0 {
    public static void a(View view, a0 a0Var) {
        view.setTag(androidx.lifecycle.e0.a.a, a0Var);
    }
}
