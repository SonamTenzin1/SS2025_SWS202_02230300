package androidx.lifecycle;

/* compiled from: ViewModelStoreOwner.java */
/* loaded from: classes.dex */
public interface a0 {
    z getViewModelStore();
}
