package androidx.lifecycle;

import android.view.View;

/* compiled from: ViewTreeLifecycleOwner.java */
/* loaded from: classes.dex */
public class b0 {
    public static void a(View view, k kVar) {
        view.setTag(androidx.lifecycle.d0.a.a, kVar);
    }
}
