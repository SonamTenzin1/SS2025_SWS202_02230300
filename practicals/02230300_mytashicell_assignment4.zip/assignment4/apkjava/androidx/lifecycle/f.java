package androidx.lifecycle;

import androidx.lifecycle.g;

/* compiled from: GeneratedAdapter.java */
/* loaded from: classes.dex */
public interface f {
    void a(k kVar, g.b bVar, boolean z, p pVar);
}
