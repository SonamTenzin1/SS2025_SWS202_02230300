package androidx.lifecycle;

/* loaded from: classes.dex */
public interface DefaultLifecycleObserver extends e {
    @Override // androidx.lifecycle.e
    void onCreate(k kVar);

    @Override // androidx.lifecycle.e
    void onDestroy(k kVar);

    @Override // androidx.lifecycle.e
    void onPause(k kVar);

    @Override // androidx.lifecycle.e
    void onResume(k kVar);

    @Override // androidx.lifecycle.e
    void onStart(k kVar);

    @Override // androidx.lifecycle.e
    void onStop(k kVar);
}
