package androidx.lifecycle;

import androidx.lifecycle.g;

/* loaded from: classes.dex */
class Lifecycling$1 implements i {
    final /* synthetic */ i a;

    @Override // androidx.lifecycle.i
    public void a(k kVar, g.b bVar) {
        this.a.a(kVar, bVar);
    }
}
