package androidx.lifecycle.d0;

/* loaded from: classes.dex */
public final class a {
    public static final int a = 2131297411;
}
