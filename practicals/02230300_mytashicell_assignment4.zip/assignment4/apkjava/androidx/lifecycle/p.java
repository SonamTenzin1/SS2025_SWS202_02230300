package androidx.lifecycle;

import java.util.HashMap;
import java.util.Map;

/* compiled from: MethodCallsLogger.java */
/* loaded from: classes.dex */
public class p {
    private Map<String, Integer> a = new HashMap();
}
