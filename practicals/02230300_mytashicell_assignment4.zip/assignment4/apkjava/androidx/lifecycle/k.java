package androidx.lifecycle;

/* compiled from: LifecycleOwner.java */
/* loaded from: classes.dex */
public interface k {
    g getLifecycle();
}
