package androidx.lifecycle;

/* compiled from: MutableLiveData.java */
/* loaded from: classes.dex */
public class q<T> extends LiveData<T> {
    @Override // androidx.lifecycle.LiveData
    public void l(T t) {
        super.l(t);
    }

    @Override // androidx.lifecycle.LiveData
    public void n(T t) {
        super.n(t);
    }
}
