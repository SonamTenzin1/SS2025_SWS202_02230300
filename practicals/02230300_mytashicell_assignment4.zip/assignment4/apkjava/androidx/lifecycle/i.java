package androidx.lifecycle;

import androidx.lifecycle.g;

/* compiled from: LifecycleEventObserver.java */
/* loaded from: classes.dex */
public interface i extends j {
    void a(k kVar, g.b bVar);
}
