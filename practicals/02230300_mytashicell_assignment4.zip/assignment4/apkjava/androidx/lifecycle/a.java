package androidx.lifecycle;

/* compiled from: AndroidViewModel.java */
/* loaded from: classes.dex */
public class a extends x {
}
