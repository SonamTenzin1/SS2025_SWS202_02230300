package androidx.lifecycle;

/* compiled from: DefaultLifecycleObserver.java */
/* loaded from: classes.dex */
public final /* synthetic */ class c {
    public static void a(DefaultLifecycleObserver defaultLifecycleObserver, k kVar) {
    }

    public static void b(DefaultLifecycleObserver defaultLifecycleObserver, k kVar) {
    }

    public static void c(DefaultLifecycleObserver defaultLifecycleObserver, k kVar) {
    }

    public static void d(DefaultLifecycleObserver defaultLifecycleObserver, k kVar) {
    }

    public static void e(DefaultLifecycleObserver defaultLifecycleObserver, k kVar) {
    }

    public static void f(DefaultLifecycleObserver defaultLifecycleObserver, k kVar) {
    }
}
