package androidx.lifecycle;

/* compiled from: LifecycleRegistryOwner.java */
@Deprecated
/* loaded from: classes.dex */
public interface m extends k {
    @Override // androidx.lifecycle.k
    l getLifecycle();
}
