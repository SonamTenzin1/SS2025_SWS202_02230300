package androidx.lifecycle.e0;

/* loaded from: classes.dex */
public final class a {
    public static final int a = 2131297413;
}
