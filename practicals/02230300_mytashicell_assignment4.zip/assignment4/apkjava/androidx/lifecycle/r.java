package androidx.lifecycle;

/* compiled from: Observer.java */
/* loaded from: classes.dex */
public interface r<T> {
    void a(T t);
}
