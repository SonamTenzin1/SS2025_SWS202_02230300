package androidx.lifecycle;

/* compiled from: LifecycleObserver.java */
/* loaded from: classes.dex */
public interface j {
}
