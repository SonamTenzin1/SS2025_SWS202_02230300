package androidx.media;

import androidx.versionedparcelable.b;

/* loaded from: classes.dex */
interface AudioAttributesImpl extends b {
}
