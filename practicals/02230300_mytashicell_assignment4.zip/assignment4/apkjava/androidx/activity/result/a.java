package androidx.activity.result;

import android.annotation.SuppressLint;

/* compiled from: ActivityResultCallback.java */
/* loaded from: classes.dex */
public interface a<O> {
    void a(@SuppressLint({"UnknownNullness"}) O o);
}
