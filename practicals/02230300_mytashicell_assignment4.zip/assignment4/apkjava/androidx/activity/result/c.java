package androidx.activity.result;

/* compiled from: ActivityResultRegistryOwner.java */
/* loaded from: classes.dex */
public interface c {
    ActivityResultRegistry getActivityResultRegistry();
}
