package androidx.activity.result;

import android.annotation.SuppressLint;

/* compiled from: ActivityResultLauncher.java */
/* loaded from: classes.dex */
public abstract class b<I> {
    public void a(@SuppressLint({"UnknownNullness"}) I i2) {
        b(i2, null);
    }

    public abstract void b(@SuppressLint({"UnknownNullness"}) I i2, androidx.core.app.b bVar);

    public abstract void c();
}
