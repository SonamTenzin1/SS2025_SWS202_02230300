package androidx.activity;

/* compiled from: Cancellable.java */
/* loaded from: classes.dex */
interface a {
    void cancel();
}
