package androidx.activity.d;

import android.content.Context;

/* compiled from: OnContextAvailableListener.java */
/* loaded from: classes.dex */
public interface b {
    void a(Context context);
}
