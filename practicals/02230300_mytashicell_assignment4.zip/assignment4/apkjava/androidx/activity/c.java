package androidx.activity;

import androidx.lifecycle.k;

/* compiled from: OnBackPressedDispatcherOwner.java */
/* loaded from: classes.dex */
public interface c extends k {
    OnBackPressedDispatcher getOnBackPressedDispatcher();
}
