package androidx.fragment.app;

import android.util.AndroidRuntimeException;

/* compiled from: SuperNotCalledException.java */
/* loaded from: classes.dex */
final class c0 extends AndroidRuntimeException {
    public c0(String str) {
        super(str);
    }
}
