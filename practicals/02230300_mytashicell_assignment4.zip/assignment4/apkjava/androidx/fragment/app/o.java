package androidx.fragment.app;

/* compiled from: FragmentOnAttachListener.java */
/* loaded from: classes.dex */
public interface o {
    void a(FragmentManager fragmentManager, Fragment fragment);
}
