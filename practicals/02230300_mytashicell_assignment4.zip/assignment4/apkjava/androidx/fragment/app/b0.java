package androidx.fragment.app;

import android.view.ViewGroup;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: SpecialEffectsControllerFactory.java */
/* loaded from: classes.dex */
public interface b0 {
    a0 a(ViewGroup viewGroup);
}
