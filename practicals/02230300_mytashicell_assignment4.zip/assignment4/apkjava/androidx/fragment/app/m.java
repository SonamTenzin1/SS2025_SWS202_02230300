package androidx.fragment.app;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: FragmentManagerImpl.java */
/* loaded from: classes.dex */
public class m extends FragmentManager {
}
