package androidx.constraintlayout.widget;

/* compiled from: ConstraintsChangedListener.java */
/* loaded from: classes.dex */
public abstract class f {
}
