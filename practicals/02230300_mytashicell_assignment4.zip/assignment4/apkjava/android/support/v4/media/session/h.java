package android.support.v4.media.session;

import android.media.session.PlaybackState;
import android.os.Bundle;

/* compiled from: PlaybackStateCompatApi22.java */
/* loaded from: classes.dex */
class h {
    public static Bundle a(Object obj) {
        return ((PlaybackState) obj).getExtras();
    }
}
