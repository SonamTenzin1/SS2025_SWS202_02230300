package android.support.v4.media;

/* compiled from: MediaBrowserCompat.java */
/* loaded from: classes.dex */
public abstract class a {
}
