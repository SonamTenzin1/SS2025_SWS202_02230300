package android.support.v4.media.session;

/* compiled from: MediaControllerCompat.java */
/* loaded from: classes.dex */
public final class d {
    private final int a;

    /* renamed from: b, reason: collision with root package name */
    private final int f58b;

    /* renamed from: c, reason: collision with root package name */
    private final int f59c;

    /* renamed from: d, reason: collision with root package name */
    private final int f60d;

    /* renamed from: e, reason: collision with root package name */
    private final int f61e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(int i2, int i3, int i4, int i5, int i6) {
        this.a = i2;
        this.f58b = i3;
        this.f59c = i4;
        this.f60d = i5;
        this.f61e = i6;
    }
}
