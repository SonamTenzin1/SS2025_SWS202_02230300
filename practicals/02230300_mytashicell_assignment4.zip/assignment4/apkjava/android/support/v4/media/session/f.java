package android.support.v4.media.session;

import android.media.session.MediaSession;

/* compiled from: MediaSessionCompatApi21.java */
/* loaded from: classes.dex */
class f {
    public static Object a(Object obj) {
        return ((MediaSession.QueueItem) obj).getDescription();
    }

    public static long b(Object obj) {
        return ((MediaSession.QueueItem) obj).getQueueId();
    }
}
